from django.apps import AppConfig


class AgenceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'agence'
