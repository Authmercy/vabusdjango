from django.contrib import admin

from gestionagence.models import Gestionagence

# Register your models here.
admin.site.register(Gestionagence)